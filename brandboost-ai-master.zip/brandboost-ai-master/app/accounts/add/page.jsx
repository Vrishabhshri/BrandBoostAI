import React from 'react'

function add() {
  return (
    <div>
      ejoi
    </div>
  )
}

export default add
